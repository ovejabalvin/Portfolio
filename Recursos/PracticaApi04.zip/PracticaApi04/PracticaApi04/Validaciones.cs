namespace Practica04Api
{
    public static class Validaciones
    {
        public static bool ValidarProducto(Producto producto, out string error)
        {
            // Validar ID
            if (producto.Id < 0)
            {
                error = "El ID debe ser mayor o igual a 0.";
                return false;
            }

            // Validar Nombre
            if (string.IsNullOrWhiteSpace(producto.Nombre) || producto.Nombre.Length > 100 || !producto.Nombre.All(Char.IsLetter))
            {
                error = "El nombre debe contener solo letras y tener menos de 100 caracteres.";
                return false;
            }

            // Validar Email
            if (!ValidarEmail(producto.AtencionEmail))
            {
                error = "El correo electr�nico de atenci�n no es v�lido.";
                return false;
            }

            error = string.Empty;
            return true;
        }

        public static bool ValidarEmail(string email)
        {
            var regex = new System.Text.RegularExpressions.Regex(@"^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$");
            return regex.IsMatch(email);
        }
    }

}