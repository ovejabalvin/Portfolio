namespace Practica04Api
{
	public static class ProductoDatabase
	{
		public static List<Producto> Productos { get; } = new List<Producto>();
		public static int ContadorId = 1;
	}
}