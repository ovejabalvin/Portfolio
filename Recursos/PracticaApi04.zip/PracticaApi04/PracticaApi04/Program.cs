namespace Pratica04Api
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);
            var app = builder.Build();

            // Rutas para la gesti�n de productos

            // Obtener todos los productos
            app.MapGet("/productos", ProductoManager.ListarProductos);

            // Obtener un producto por ID
            app.MapGet("/productos/{id:int}", (int id) => ProductoManager.ObtenerProductoPorId(id));

            // Crear un nuevo producto
            app.MapPost("/productos", (Producto nuevoProducto) => ProductoManager.CrearProducto(nuevoProducto));

            // Actualizar un producto completo (PUT)
            app.MapPut("/productos/{id:int}", (int id, Producto productoActualizado) => ProductoManager.ActualizarProducto(id, productoActualizado));

            // Actualizar parcialmente un producto (PATCH)
            app.MapPatch("/productos/{id:int}", (int id, string? nombre, decimal? precio, string? atencionEmail) =>
                ProductoManager.ActualizarParcialProducto(id, nombre, precio, atencionEmail));

            // Eliminar un producto por ID
            app.MapDelete("/productos/{id:int}", (int id) => ProductoManager.EliminarProducto(id));

            // Ejecutar la aplicaci�n
            app.Run();

        }
    }
}