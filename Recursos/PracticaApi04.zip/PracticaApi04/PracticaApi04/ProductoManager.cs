namespace PracticaApi04
{
    public static class ProductoManager
    {
        public static IResult ListarProductos()
            {
            return Results.ok(ProductoDatabase.Productos)
        }

    public static IResult ObtenerProductoPorId(int id)
        {
            foreach(var producto in ProductoDatabase.Productos) {
                if (producto.Id == id)
                {
                    return Results.Ok(producto);
                }
        }
            return Results.NotFound("Producto no encontrado")
        }

        public static IResult CrearProducto(Producto nuevoProducto)
        {
            nuevoProducto.Id = ProductoDatabase.ContadorId++;
            string error;
            if (!Validaciones.ValidarProducto(nuevoProducto, out error))
            {
                return Results.BadRequest(error);
            }

            ProductoDatabase.Productos.Add(nuevoProducto);
            return Results.Created($"/productos/{nuevoProducto.Id}", nuevoProducto);
        }

        public static IResult ActualizarProducto(int id, Producto productoActualizado)
        {
            foreach (var producto in ProductoDatabase.Productos)
            {
                if (producto.Id == id)
                {
                    string error;
                    if (!Validaciones.ValidarProducto(productoActualizado, out error))
                    {
                        return Results.BadRequest(error);
                    }

                    producto.Nombre = productoActualizado.Nombre;
                    producto.Precio = productoActualizado.Precio;
                    producto.AtencionEmail = productoActualizado.AtencionEmail;
                    return Results.Ok(producto);
                }
            }
            return Results.NotFound("Producto no encontrado.");
        }

        public static IResult ActualizarParcialProducto(int id, string nombre = null, decimal? precio = null, string atencionEmail = null)
        {
            foreach (var producto in ProductoDatabase.Productos)
            {
                if (producto.Id == id)
                {
                    // Validaciones parciales
                    if (nombre != null && (nombre.Length > 100 || !nombre.All(Char.IsLetter)))
                    {
                        return Results.BadRequest("El nombre debe contener solo letras y tener menos de 100 caracteres.");
                    }

                    if (atencionEmail != null && !Validaciones.ValidarEmail(atencionEmail))
                    {
                        return Results.BadRequest("El correo electr�nico de atenci�n no es v�lido.");
                    }

                    if (nombre != null) producto.Nombre = nombre;
                    if (precio != null) producto.Precio = precio.Value;
                    if (atencionEmail != null) producto.AtencionEmail = atencionEmail;

                    return Results.Ok(producto);
                }
            }
            return Results.NotFound("Producto no encontrado.");
        }

        public static IResult EliminarProducto(int id)
        {
            for (int i = 0; i < ProductoDatabase.Productos.Count; i++)
            {
                if (ProductoDatabase.Productos[i].Id == id)
                {
                    ProductoDatabase.Productos.RemoveAt(i);
                    return Results.NoContent();
                }
            }
            return Results.NotFound("Producto no encontrado.");
        }
    }

}
