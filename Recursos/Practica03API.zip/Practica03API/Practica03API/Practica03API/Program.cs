namespace Practica03API
{

    
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);
            var app = builder.Build();

            // Rutas para la gesti�n de viajes en la API de carpooling

            // Listado de Viajes Disponibles
            app.MapGet("/viajes", ViajeManager.ListarViajes);

            // Detalles de un Viaje por ID
            app.MapGet("/viajes/{id:int}", ViajeManager.ObtenerViajePorId);

            // Publicar un Viaje
            app.MapPost("/viajes", ViajeManager.PublicarViaje);

            // Reservar un Asiento en un Viaje
            app.MapPost("/viajes/reservar/{id:int}", ViajeManager.ReservarAsiento);

            // Cancelar un Viaje
            app.MapDelete("/viajes/{id:int}", ViajeManager.CancelarViaje);

            // Ejecutar la aplicaci�n
            app.Run();

        }
    }
}